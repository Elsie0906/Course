#pragma once

void _ldainit(unsigned long pagesize, unsigned long pages);
void *_ldalloc(unsigned long size);
