[ Please begin by replacing this file with "k1-README.txt" from the spec. ]
