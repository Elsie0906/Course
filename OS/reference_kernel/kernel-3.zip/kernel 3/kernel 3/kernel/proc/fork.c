/******************************************************************************/
/* Important Summer 2018 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/*         53616c7465645f5fd1e93dbf35cbffa3aef28f8c01d8cf2ffc51ef62b26a       */
/*         f9bda5a68e5ed8c972b17bab0f42e24b19daa7bd408305b1f7bd6c7208c1       */
/*         0e36230e913039b3046dd5fd0ba706a624d33dbaa4d6aab02c82fe09f561       */
/*         01b0fd977b0051f0b0ce0c69f7db857b1b5e007be2db6d42894bf93de848       */
/*         806d9152bd5715e9                                                   */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "types.h"
#include "globals.h"
#include "errno.h"

#include "util/debug.h"
#include "util/string.h"

#include "proc/proc.h"
#include "proc/kthread.h"

#include "mm/mm.h"
#include "mm/mman.h"
#include "mm/page.h"
#include "mm/pframe.h"
#include "mm/mmobj.h"
#include "mm/pagetable.h"
#include "mm/tlb.h"

#include "fs/file.h"
#include "fs/vnode.h"

#include "vm/shadow.h"
#include "vm/vmmap.h"

#include "api/exec.h"

#include "main/interrupt.h"

/* Pushes the appropriate things onto the kernel stack of a newly forked thread
 * so that it can begin execution in userland_entry.
 * regs: registers the new thread should have on execution
 * kstack: location of the new thread's kernel stack
 * Returns the new stack pointer on success. */
static uint32_t
fork_setup_stack(const regs_t *regs, void *kstack)
{
        /* Pointer argument and dummy return address, and userland dummy return
         * address */
        uint32_t esp = ((uint32_t) kstack) + DEFAULT_STACK_SIZE - (sizeof(regs_t) + 12);
        *(void **)(esp + 4) = (void *)(esp + 8); /* Set the argument to point to location of struct on stack */
        memcpy((void *)(esp + 8), regs, sizeof(regs_t)); /* Copy over struct */
        return esp;
}


/*
 * The implementation of fork(2). Once this works,
 * you're practically home free. This is what the
 * entirety of Weenix has been leading up to.
 * Go forth and conquer.
 */
int
do_fork(struct regs *regs)
{

		KASSERT(regs != NULL); /* the function argument must be non-NULL (1 pt) (precondition) */
        KASSERT(curproc != NULL); /* the parent process, which is curproc, must be non-NULL (1 pt) (precondition) */
        KASSERT(curproc->p_state == PROC_RUNNING); /* the parent process must be in the running state and not in the zombie state (1 pt) (precondition) */
        dbg(DBG_PRINT, "(GRADING3A 7.a)\n");
        vmarea_t *vma, *clone_vma;
        pframe_t *pf;
        mmobj_t *to_delete, *new_shadowed;
	
		//Allocate a proc_t out of the procs structure using proc_create()
		char *name = "fork process";
		proc_t *newproc = proc_create(name);
		
		KASSERT(newproc->p_state == PROC_RUNNING); /* new child process starts in the running state (1 pt) (middle) */
		dbg(DBG_PRINT, "(GRADING3A 7.a)\n");	
		vput(newproc->p_cwd);
		newproc->p_cwd = curproc->p_cwd;
		vref(newproc->p_cwd);
		
		int i = 0;
		for(i=0;i<NFILES;i++)
		{
			newproc->p_files[i] = curproc->p_files[i];
			if(curproc->p_files[i]!=NULL)
			{
				//	fref(curproc->p_files[i]);
				vref(curproc->p_files[i]->f_vnode);
				dbg(DBG_PRINT, "(GRADING3B 1)\n");
			}
			dbg(DBG_PRINT, "(GRADING3B 1)\n");
		}
		newproc->p_brk = curproc->p_brk;
        newproc->p_start_brk = curproc->p_start_brk;
        
		kthread_t *newthr = kthread_clone(curthr);
        newthr->kt_proc = newproc;
        list_insert_tail(&newproc->p_threads, &newthr->kt_plink);
        
        //Copy the vmmap_t from the parent process into the child using vmmap_clone()
        vmmap_t *fork_vmmap = vmmap_clone(curproc->p_vmmap);
        
        vmarea_t *vArea_new = list_head(&(fork_vmmap->vmm_list), vmarea_t, vma_plink);
        list_iterate_begin(&curproc->p_vmmap->vmm_list, vma, vmarea_t, vma_plink) { 
        	if((vma->vma_flags & MAP_TYPE) == MAP_SHARED) {
        		vArea_new->vma_obj = vma->vma_obj;
        		vArea_new->vma_obj->mmo_ops->ref(vArea_new->vma_obj);
        		dbg(DBG_PRINT, "(GRADING3D 2)\n");
        	}
            else if((vma->vma_flags & MAP_TYPE) == MAP_PRIVATE) {
            	mmobj_t *bottom_obj = mmobj_bottom_obj(vma->vma_obj);
            	mmobj_t *obj = vma->vma_obj;
            	
            	vma->vma_obj = shadow_create();
            	vma->vma_obj->mmo_shadowed = obj;
            	vma->vma_obj->mmo_un.mmo_bottom_obj = bottom_obj;
            	
            	vArea_new->vma_obj = shadow_create();
            	vArea_new->vma_obj->mmo_shadowed = obj;
            	vArea_new->vma_obj->mmo_un.mmo_bottom_obj = bottom_obj;
            	list_insert_head(&bottom_obj->mmo_un.mmo_vmas, &vArea_new->vma_olink);
            	
            	obj->mmo_ops->ref(obj);
            	dbg(DBG_PRINT, "(GRADING3B 1)\n");
            }
            vArea_new = list_item(vArea_new->vma_plink.l_next, vmarea_t, vma_plink);
            dbg(DBG_PRINT, "(GRADING3B 1)\n");
        }list_iterate_end();
            
        fork_vmmap->vmm_proc = newproc;
        newproc->p_vmmap = fork_vmmap;   
        
        newthr->kt_ctx.c_pdptr = newproc->p_pagedir;
        newthr->kt_ctx.c_eip = (uint32_t)(userland_entry);
        
        regs->r_eax = 0;
        newthr->kt_ctx.c_esp = (uint32_t)fork_setup_stack(regs, newthr->kt_kstack);
        newthr->kt_ctx.c_kstack = (uintptr_t)newthr->kt_kstack;
        newthr->kt_ctx.c_kstacksz = DEFAULT_STACK_SIZE;
        newthr->kt_ctx.c_ebp = curthr->kt_ctx.c_ebp;
        //newproc->p_status=0;
        KASSERT(newproc->p_pagedir != NULL); /* new child process must have a valid page table (1 pt) (middle) */
        KASSERT(newthr->kt_kstack != NULL); /* thread in the new child process must have a valid kernel stack     (1 pt) (middle) */
		dbg(DBG_PRINT, "(GRADING3A 7.a)\n");
        //Unmap the user land page table entries and flush the TLB (using pt_unmap_range() and tlb_flush_all()).
        tlb_flush_all();
        pt_unmap_range(curproc->p_pagedir, USER_MEM_LOW, USER_MEM_HIGH);
        sched_make_runnable(newthr);
		dbg(DBG_PRINT, "(GRADING3B 1)\n");
        return newproc->p_pid;     
}
