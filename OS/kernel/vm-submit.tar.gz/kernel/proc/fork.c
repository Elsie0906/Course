/******************************************************************************/
/* Important Fall 2018 CSCI 402 usage information:                            */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/*         53616c7465645f5fd1e93dbf35cbffa3aef28f8c01d8cf2ffc51ef62b26a       */
/*         f9bda5a68e5ed8c972b17bab0f42e24b19daa7bd408305b1f7bd6c7208c1       */
/*         0e36230e913039b3046dd5fd0ba706a624d33dbaa4d6aab02c82fe09f561       */
/*         01b0fd977b0051f0b0ce0c69f7db857b1b5e007be2db6d42894bf93de848       */
/*         806d9152bd5715e9                                                   */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "types.h"
#include "globals.h"
#include "errno.h"

#include "util/debug.h"
#include "util/string.h"

#include "proc/proc.h"
#include "proc/kthread.h"

#include "mm/mm.h"
#include "mm/mman.h"
#include "mm/page.h"
#include "mm/pframe.h"
#include "mm/mmobj.h"
#include "mm/pagetable.h"
#include "mm/tlb.h"

#include "fs/file.h"
#include "fs/vnode.h"

#include "vm/shadow.h"
#include "vm/vmmap.h"

#include "api/exec.h"

#include "main/interrupt.h"

/* Pushes the appropriate things onto the kernel stack of a newly forked thread
 * so that it can begin execution in userland_entry.
 * regs: registers the new thread should have on execution
 * kstack: location of the new thread's kernel stack
 * Returns the new stack pointer on success. */
static uint32_t
fork_setup_stack(const regs_t *regs, void *kstack)
{
        /* Pointer argument and dummy return address, and userland dummy return
         * address */
        uint32_t esp = ((uint32_t) kstack) + DEFAULT_STACK_SIZE - (sizeof(regs_t) + 12);
        *(void **)(esp + 4) = (void *)(esp + 8); /* Set the argument to point to location of struct on stack */
        memcpy((void *)(esp + 8), regs, sizeof(regs_t)); /* Copy over struct */
        return esp;
}


/*
 * The implementation of fork(2). Once this works,
 * you're practically home free. This is what the
 * entirety of Weenix has been leading up to.
 * Go forth and conquer.
 */
int
do_fork(struct regs *regs)
{
        //aar
        KASSERT(regs != NULL); /* the function argument must be non-NULL (1 pt) (precondition) */
        KASSERT(curproc != NULL); /* the parent process, which is curproc, must be non-NULL (1 pt) (precondition) */
        KASSERT(curproc->p_state == PROC_RUNNING); /* the parent process must be in the running state and not in the zombie state (1 pt) (precondition) */
        dbg(DBG_PRINT, "(GRADING3A 7.a)\n");

        vmarea_t *vma, *clone_vma;
        pframe_t *pf;
        mmobj_t *to_delete, *new_shadowed;

        proc_t *newproc = proc_create("new_process");

        vmmap_t *fork_vmmap = vmmap_clone(curproc->p_vmmap);
        fork_vmmap->vmm_proc = newproc;
        newproc->p_vmmap = fork_vmmap;  

        vmarea_t *vma_new;
        vmarea_t *vma_old;
        vmmap_t *old_map = curproc->p_vmmap;
        list_link_t *link = (&old_map->vmm_list)->l_next;

        list_iterate_begin(&fork_vmmap->vmm_list, vma_new, vmarea_t, vma_plink) {
            vma_old = list_item(link, vmarea_t, vma_plink);
            if ((vma_new->vma_flags & MAP_PRIVATE) == MAP_PRIVATE) {
                mmobj_t *newproc_shadow = shadow_create();
                if (newproc_shadow == NULL) {
                    vmmap_destroy(fork_vmmap);
                    return -1;
                }
                newproc_shadow->mmo_shadowed = vma_old->vma_obj;
                newproc_shadow->mmo_un.mmo_bottom_obj = mmobj_bottom_obj(vma_old->vma_obj);
                list_insert_tail(mmobj_bottom_vmas(vma_old->vma_obj), &(vma_new->vma_olink));
                vma_new->vma_obj = newproc_shadow;
            } else if ((vma_new->vma_flags & MAP_SHARED) == MAP_SHARED) {
                vma_new->vma_obj = vma_old->vma_obj;
            }            
            vma_old->vma_obj->mmo_ops->ref(vma_old->vma_obj);
            link = link->l_next;
        } list_iterate_end();
        
        list_iterate_begin(&old_map->vmm_list, vma_old, vmarea_t, vma_plink) {
            if ((vma_old->vma_flags & MAP_PRIVATE) == MAP_PRIVATE) {
                mmobj_t *oldproc_shadow = shadow_create();
                if (oldproc_shadow == NULL) {
                    vmmap_destroy(fork_vmmap);
                    return -1;
                }
                oldproc_shadow->mmo_shadowed = vma_old->vma_obj;
                oldproc_shadow->mmo_un.mmo_bottom_obj = mmobj_bottom_obj(vma_old->vma_obj);
                vma_old->vma_obj = oldproc_shadow;
            }
        } list_iterate_end();
        
        pt_unmap_range(curproc->p_pagedir, USER_MEM_LOW, USER_MEM_HIGH);
        tlb_flush_all();
        
        vput(newproc->p_cwd);
        newproc->p_cwd = curproc->p_cwd;
        vref(newproc->p_cwd);       

        kthread_t *newthr = kthread_clone(curthr);
        newthr->kt_proc = newproc;
        newproc->p_brk = curproc->p_brk;
        newproc->p_start_brk = curproc->p_start_brk;

        newthr->kt_ctx.c_pdptr = newproc->p_pagedir;
        regs->r_eax = 0;
        newthr->kt_ctx.c_esp = (uint32_t) fork_setup_stack(regs, (void *) newthr->kt_kstack);
        newthr->kt_ctx.c_ebp = curthr->kt_ctx.c_ebp;
        newthr->kt_ctx.c_eip = (uint32_t) (userland_entry);
        newthr->kt_ctx.c_kstack = (uintptr_t)newthr->kt_kstack;
        newthr->kt_ctx.c_kstacksz = DEFAULT_STACK_SIZE;

        list_insert_tail(&newproc->p_threads, &newthr->kt_plink);

        KASSERT(newproc->p_state == PROC_RUNNING); /* new child process starts in the running state (1 pt) (middle) */
        KASSERT(newproc->p_pagedir != NULL); /* new child process must have a valid page table (1 pt) (middle) */
        KASSERT(newthr->kt_kstack != NULL); /* thread in the new child process must have a valid kernel stack (1 pt) (middle) */
        dbg(DBG_PRINT, "(GRADING3A 7.a)\n");

        int fd = 0;
        while (fd < NFILES) {
            newproc->p_files[fd] = curproc->p_files[fd];
            if (curproc->p_files[fd] != NULL) {
                vref(curproc->p_files[fd]->f_vnode);
                dbg(DBG_PRINT, "(GRADING3B 1)\n");
            }
            dbg(DBG_PRINT, "(GRADING3B 1)\n");
            fd ++;
        }

        sched_make_runnable(newthr);
        dbg(DBG_PRINT, "(GRADING3B 1)\n");
        return newproc->p_pid; 
}
